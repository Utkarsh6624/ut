package com.fallenblood.freecodecamp_radio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
