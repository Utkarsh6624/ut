part of 'radio_bloc.dart';

@immutable
sealed class RadioEvent {}

class RadioFetchEvent extends RadioEvent{}
